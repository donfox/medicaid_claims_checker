Ignored: not .x12, .edi or .json
